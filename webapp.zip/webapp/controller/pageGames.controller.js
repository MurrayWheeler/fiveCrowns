"use-strict";


fiveCrowns.pageGamesController = (function () {



//     return {


//     };

}());
