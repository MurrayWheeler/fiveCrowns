"use-strict";


fiveCrowns.pageInstrController = (function () {


    return {

        onBack: function (oApp) {
            oApp.back();
        },


    };

}());
