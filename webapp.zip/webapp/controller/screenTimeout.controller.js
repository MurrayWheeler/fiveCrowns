// This global script will stop the screen timeout using wakeLock

// After a period of inactivity the wakeLock is released,
// this is done for security and battery saving reasons.
// IE If we are no longer using the app, don't leave the screen open forever


// ToDo
// Test
// Add timeout duration to settings
// Remove unwanted console logs. Maybe? where do they go normally? Maybe they can stay for debugging purpose?


//let timeoutDuration = 300000; // 5 minutes (in milliseconds)
let timeoutDuration = 30000; // 30 seconds (in milliseconds) for testing
let timeoutID;
let wakeLock = null;

// Function to request screen wake lock
async function requestWakeLock() {
    debugger;
    try {
        if ('wakeLock' in navigator) {
            wakeLock = await navigator.wakeLock.request('screen');
            console.log("Screen wake lock acquired");

            // Optional: Handle the release event (when the wake lock is released)
            wakeLock.addEventListener('release', () => {
                console.log('Wake lock released');
            });
        }
    } catch (err) {
        console.error('Failed to acquire wake lock:', err);
    }
}

// Function to release the wake lock
async function releaseWakeLock() {
    debugger;
    if (wakeLock) {
        try {
            await wakeLock.release();  // Release the wake lock
            console.log('Wake lock released');
            wakeLock = null;  // Reset the wake lock object after releasing it
        } catch (err) {
            console.error('Failed to release wake lock:', err);
        }
    } else {
        console.log('No wake lock to release');
    }
}


// Reset the release wakeLock timeout
function resetTimeout() {
    debugger;
    clearTimeout(timeoutID);  // Reset the previous timeout
    timeoutID = setTimeout(releaseWakeLock, timeoutDuration);  // Set a new timeout

    // Ensure the screen stays on as long as the user is active
    if (!wakeLock) {
        requestWakeLock(); // Request wake lock if it's not already active
    }
}


// Listen for user activity
window.onload = resetTimeout;  // Start the timeout when the page loads
document.onmousemove = resetTimeout;  // Reset timeout on mouse move
document.onkeydown = resetTimeout;  // Reset timeout on key press
document.onclick = resetTimeout;  // Reset timeout on click

// Optional: Detect touch or swipe events for mobile users
document.ontouchstart = resetTimeout;  // Reset timeout on touch




// // Example usage:

// // Request the wake lock when needed
// requestWakeLock();

// // Later, when you want to release the wake lock (e.g., after user logs out or session ends)
// releaseWakeLock();





// let timeoutDuration = 300000; // 5 minutes (in milliseconds)
// let timeoutID;
// let wakeLock = null;

// // Function to request screen wake lock
// async function requestWakeLock() {
//     try {
//         if ('wakeLock' in navigator) {
//             wakeLock = await navigator.wakeLock.request('screen');
//             console.log("Screen wake lock acquired");
//             wakeLock.addEventListener('release', () => {
//                 console.log('Wake lock released');
//             });
//         }
//     } catch (err) {
//         console.error('Failed to acquire wake lock:', err);
//     }
// }

// function resetTimeout() {
//     debugger;
//     clearTimeout(timeoutID);  // Reset the previous timeout
//     timeoutID = setTimeout(logOutUser, timeoutDuration);  // Set a new timeout

//     // Ensure the screen stays on as long as the user is active
//     if (!wakeLock) {
//         requestWakeLock(); // Request wake lock if it's not already active
//     }
// }

// function logOutUser() {
//     // Action when the session times out (e.g., show a message or redirect)
//     alert("Your session has expired due to inactivity.");
//     window.location.href = '/login';  // Redirect to login page
// }

// // Listen for user activity
// window.onload = resetTimeout;  // Start the timeout when the page loads
// document.onmousemove = resetTimeout;  // Reset timeout on mouse move
// document.onkeydown = resetTimeout;  // Reset timeout on key press
// document.onclick = resetTimeout;  // Reset timeout on click

// // Optional: Detect touch or swipe events for mobile users
// document.ontouchstart = resetTimeout;  // Reset timeout on touch
